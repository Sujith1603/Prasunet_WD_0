document.addEventListener("DOMContentLoaded", () => {
    const cells = document.querySelectorAll(".cell");
    const statusText = document.querySelector(".status");
    const resetButton = document.getElementById("resetButton");
    const winningLine = document.querySelector(".winning-line");
    let currentPlayer = "X";
    let board = Array(9).fill(null);
    let gameActive = true;

    const winningCombinations = [
        [0, 1, 2],
        [3, 4, 5],
        [6, 7, 8],
        [0, 3, 6],
        [1, 4, 7],
        [2, 5, 8],
        [0, 4, 8],
        [2, 4, 6]
    ];

    function handleClick(event) {
        const index = event.target.getAttribute("data-index");
        if (board[index] || !gameActive) return;

        board[index] = currentPlayer;
        event.target.textContent = currentPlayer;
        checkWinner();
        currentPlayer = currentPlayer === "X" ? "O" : "X";
    }

    function checkWinner() {
        for (const combination of winningCombinations) {
            const [a, b, c] = combination;
            if (board[a] && board[a] === board[b] && board[a] === board[c]) {
                statusText.textContent = `${board[a]} wins!`;
                gameActive = false;
                displayWinningLine(combination);
                return;
            }
        }

        if (!board.includes(null)) {
            statusText.textContent = "It's a draw!";
            gameActive = false;
        }
    }

    function displayWinningLine(combination) {
        const [a, b, c] = combination;
        const firstCell = cells[a];
        const lastCell = cells[c];

        const start = firstCell.getBoundingClientRect();
        const end = lastCell.getBoundingClientRect();

        const angle = Math.atan2(end.top - start.top, end.left - start.left) * 180 / Math.PI;
        const length = Math.sqrt(Math.pow(end.top - start.top, 2) + Math.pow(end.left - start.left, 2));

        winningLine.style.width = `${length}px`;
        winningLine.style.transform = `rotate(${angle}deg)`;
        winningLine.style.top = `${start.top + window.scrollY + start.height / 2}px`;
        winningLine.style.left = `${start.left + window.scrollX + start.width / 2}px`;
        winningLine.style.display = "block";
    }

    function resetGame() {
        board.fill(null);
        cells.forEach(cell => cell.textContent = "");
        statusText.textContent = "";
        currentPlayer = "X";
        gameActive = true;
        winningLine.style.display = "none";
    }

    cells.forEach(cell => cell.addEventListener("click", handleClick));
    resetButton.addEventListener("click", resetGame);
});
